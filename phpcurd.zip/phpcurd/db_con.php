<?php 
$con = mysqli_connect('localhost', 'root', '','phpcurd');

if(!$con){
    die(mysqli_connect_error($con));
}
?>